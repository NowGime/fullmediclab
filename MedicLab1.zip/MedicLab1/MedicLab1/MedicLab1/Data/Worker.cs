﻿using System;
using System.Collections.Generic;

namespace MedicLab1.Data;

public partial class Worker
{
    public int Id { get; set; }

    public string Login { get; set; } = null!;

    public string Password { get; set; } = null!;

    public string Fslname { get; set; } = null!;

    public string Brthday { get; set; } = null!;

    public string Serialpasname { get; set; } = null!;

    public string Telephone { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string? Numstrah { get; set; }

    public string? Typestrah { get; set; }

    public string? Namestrah { get; set; }

    public string Role { get; set; } = null!;
}
