using System;
using Avalonia.Controls;
using MedicLab1.Data;
using MedicLab1.Views;

namespace MedicLab1.Classes;

public static class Help
{
    public static ContentControl CCV = new MainView();
    public static TestContext DB = new TestContext();
}