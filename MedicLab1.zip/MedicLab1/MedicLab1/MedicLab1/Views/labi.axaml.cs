using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using MedicLab1.Classes;

namespace MedicLab1.Views;

public partial class labi : UserControl
{
    public labi()
    {
        InitializeComponent();
    }

    private void Exit1_OnClick(object? sender, RoutedEventArgs e)
    {
        Help.CCV.Content = new MainView();
    }
}