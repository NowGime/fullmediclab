using Avalonia.Controls;
using MedicLab1.Classes;

namespace MedicLab1.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        Help.CCV = MainCC;
        Help.CCV.Content = new MainView();
    }
}