using System.Linq;
using Avalonia.Controls;
using Avalonia.Interactivity;
using MedicLab1.Classes;
using Microsoft.EntityFrameworkCore;
using MsBox.Avalonia;

namespace MedicLab1.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
    }

    private void Button_OnClick(object? sender, RoutedEventArgs e)
    {
        Help.DB.Workers.Load();
        var lb = Help.DB.Workers.FirstOrDefault(el => el.Login == LoginTb.Text && el.Password == PassTb.Text && el.Role == "lab");
        if (lb != null)
        {
            Help.CCV.Content = new lab();
        }
        
        var lbi = Help.DB.Workers.FirstOrDefault(el => el.Login == LoginTb.Text && el.Password == PassTb.Text && el.Role == "labi");
        if (lbi != null)
        {
            Help.CCV.Content = new labi();
        }
        
        var bh = Help.DB.Workers.FirstOrDefault(el => el.Login == LoginTb.Text && el.Password == PassTb.Text && el.Role == "buh");
        if (bh != null)
        {
            Help.CCV.Content = new buh();
        }
        
        var admn = Help.DB.Workers.FirstOrDefault(el => el.Login == LoginTb.Text && el.Password == PassTb.Text && el.Role == "admin");
        if (admn != null)
        {
            Help.CCV.Content = new admin();
        }

        if (lb == null && lbi == null && bh == null && admn == null)
        {
            MessageBoxManager.GetMessageBoxStandard("ОШИБКА!!!", "Неверный логин или пароль").ShowAsync();
            LoginTb.Text = "";
            PassTb.Text = "";
            return;
        }
    }
}