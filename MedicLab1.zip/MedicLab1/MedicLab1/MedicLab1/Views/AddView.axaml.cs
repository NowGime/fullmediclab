using System.Linq;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using MedicLab1.Classes;
using MedicLab1.Data;
using Microsoft.EntityFrameworkCore;

namespace MedicLab1.Views;

public partial class AddView : UserControl
{
    public int _id;
    public AddView(int id = -1)
    {
        InitializeComponent();
        Help.DB.Workers.Load();
        _id = id;

        if (id == -1)
        {
            Addpnl.DataContext = new Worker();
        }
        else
        {
            var user = Help.DB.Workers.FirstOrDefault(el => el.Id == _id);
            Addpnl.DataContext = user;
        }
    }

    private void OK_OnClick(object? sender, RoutedEventArgs e)
    {
        if (_id == -1)
        {
            Help.DB.Workers.Add(Addpnl.DataContext as Worker);
        }
        Help.DB.SaveChanges();
        Help.CCV.Content = new admin();
    }

    private void Backbtn_OnClick(object? sender, RoutedEventArgs e)
    {
        Help.CCV.Content = new admin();
    }
}