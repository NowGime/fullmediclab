using System.Linq;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using MedicLab1.Classes;
using MedicLab1.Data;
using Microsoft.EntityFrameworkCore;
using MsBox.Avalonia;

namespace MedicLab1.Views;

public partial class admin : UserControl
{
    public admin()
    {
        InitializeComponent();
        Help.DB.Workers.Load();
        MainDG.ItemsSource = Help.DB.Workers.ToList();
    }

    private void Exit1_OnClick(object? sender, RoutedEventArgs e)
    {
        Help.CCV.Content = new MainView();
    }

    private void Addbtn_OnClick(object? sender, RoutedEventArgs e)
    {
        Help.CCV.Content = new AddView();
    }

    private void Editbtn_OnClick(object? sender, RoutedEventArgs e)
    {
        var usr = MainDG.SelectedItem as Worker;
        if (usr == null)
        {
            MessageBoxManager.GetMessageBoxStandard("ОШИБКА!!!",
                "Вы не выбрали пользователя или ошибка в чем-то другом");
            return;
        }

        if (usr != null)
        {
            Help.CCV.Content = new AddView(usr.Id);
        }
    }

    private void Delbtn_OnClick(object? sender, RoutedEventArgs e)
    {
        var usrs = MainDG.SelectedItem as Worker;
        if (usrs == null)
        {
            MessageBoxManager.GetMessageBoxStandard("ОШИБКА!!!",
                "Вы не выбрали пользователя или ошибка в чем-то другом");
            return;
        }

        if (usrs != null)
        {
            Help.DB.Workers.Remove(usrs);
            Help.DB.SaveChanges();
            Help.DB.Workers.Load();
        }
    }
}