﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace MedicLab1.ViewModels;

public abstract class ViewModelBase : ObservableObject
{
}